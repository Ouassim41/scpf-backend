const express = require("express");
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const bodyParser = require("body-parser");
const nodemailer = require("nodemailer");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "supersecretkey";

app.use(cors());
app.use(bodyParser.json());

// Utilisateurs simulés en mémoire
const users = [
  {
    id: 1,
    email: "admin@scpf.com",
    passwordHash: bcrypt.hashSync("admin123", 10),
  },
];

const resetTokens = {};

const transporter = nodemailer.createTransport({
  host: "smtp-relay.brevo.com",
  port: 587,
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

app.post("/api/login", (req, res) => {
  const { email, password } = req.body;
  const user = users.find((u) => u.email === email);
  if (!user) return res.status(401).json({ message: "Utilisateur non trouvé" });

  const isValid = bcrypt.compareSync(password, user.passwordHash);
  if (!isValid) return res.status(401).json({ message: "Mot de passe incorrect" });

  const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: "1h" });
  res.json({ message: "Connexion réussie", token });
});

app.post("/api/register", (req, res) => {
  const { email, password } = req.body;
  const existingUser = users.find((u) => u.email === email);
  if (existingUser) return res.status(409).json({ message: "Utilisateur déjà inscrit" });

  const passwordHash = bcrypt.hashSync(password, 10);
  const newUser = {
    id: users.length + 1,
    email,
    passwordHash,
  };
  users.push(newUser);
  res.status(201).json({ message: "Inscription réussie" });
});

app.get("/api/users", (req, res) => {
  const userList = users.map((u) => ({ id: u.id, email: u.email }));
  res.json(userList);
});

app.post("/api/forgot-password", (req, res) => {
  const { email } = req.body;
  const user = users.find((u) => u.email === email);
  if (!user) return res.status(404).json({ message: "Aucun utilisateur trouvé avec cet email." });

  const token = Math.random().toString(36).substring(2, 10);
  resetTokens[token] = email;

  const resetLink = `https://scpf-login.vercel.app/reset.html?token=${token}`;

  const mailOptions = {
    from: '"SCPF Support" <sbaiouassim@gmail.com>',
    to: email,
    subject: "Réinitialisation de votre mot de passe",
    html: `
      <p>Bonjour,</p>
      <p>Vous avez demandé à réinitialiser votre mot de passe.</p>
      <p><a href="${resetLink}">${resetLink}</a></p>
      <p>Ce lien expirera dans quelques minutes.</p>
    `
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error("Erreur d'envoi :", error);
      return res.status(500).json({ message: "Erreur d'envoi de l'e-mail." });
    } else {
      console.log("✉️ E-mail envoyé :", info.response);
      res.json({ message: "E-mail de réinitialisation envoyé avec succès." });
    }
  });
});

app.post("/api/reset-password", (req, res) => {
  const { token, password } = req.body;
  const email = resetTokens[token];
  if (!email) return res.status(400).json({ message: "Lien invalide ou expiré." });

  const user = users.find((u) => u.email === email);
  if (!user) return res.status(404).json({ message: "Utilisateur introuvable." });

  user.passwordHash = bcrypt.hashSync(password, 10);
  delete resetTokens[token];

  res.json({ message: "Mot de passe mis à jour avec succès." });
});

app.listen(PORT, () => {
  console.log(`✅ Serveur lancé sur http://localhost:${PORT}`);
});
